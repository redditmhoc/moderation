<?php $__env->startSection('content'); ?>

<div class="ui middle aligned center aligned grid">
    <div class="five wide column">
        <div class="ui fluid card">
            <div class="content">
                <h1 class="ui huge header">MHoC Speakership
                    <div class="sub header">Submit legislation and more</div>
                </h1>
                <?php if(auth()->guard()->check()): ?>
                    <p>Hi, <?php echo e(Auth::user()->username); ?>!</p>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access')): ?>
                    <a href="<?php echo e(route('dash')); ?>" class="ui primary button">Access</a>
                    <a href="<?php echo e(route('auth.logout')); ?>" class="ui red button">Sign-out</a>
                    <?php else: ?>
                    <div class="ui negative message">
                        You are not registered as a member of Speakership. If this is a mistake, please contact the Quadrumvirate.
                    </div>
                    <a href="<?php echo e(route('auth.logout')); ?>" class="ui red button">Sign-out</a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('auth.login')); ?>" class="ui primary button">Login with Reddit</a>
                    <p style="margin-top: 10px;">We do not receive your password, nor can we read posts or post on your behalf.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-speakership/resources/views/welcome.blade.php ENDPATH**/ ?>