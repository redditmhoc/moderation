<?php $__env->startSection('title', 'View Warnings - '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="margin-top: 10px; margin-bottom: 10px;" class="ui grid container">
<div class="eight column wide">
<?php
function ordinal($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        return $number. 'th';
    else
        return $number. $ends[$number % 10];
}
?>
<a href="<?php echo e(route('dash')); ?>">◀ Dashboard</a><br>
<br>
<div class="ui grid">
    <div class="ui clearing">
        <h1 class="ui left floated header">View Warnings</h1>
        <a href="<?php echo e(route('actions.createwarning')); ?>" class="ui right floated primary button">Create Warning</a>
    </div>
</div>
<br>
<br>
<div class="ui grid">
    <table class="ui celled table">
        <thead>
            <th>Reddit Username</th>
            <th>Timestamp</th>
            <th>Actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $warnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($w->reddit_username); ?></td>
                    <td><?php echo e(Carbon\Carbon::create($w->timestamp)->toDayDateTimeString()); ?></td>
                    <td><a href="<?php echo e(route('actions.viewwarning', [$w->reddit_username, $w->id])); ?>">View Warning</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script>
    $(document).ready( function () {
    $('.table').DataTable();
    } );
</script>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-speakership/resources/views/actions/viewWarnings.blade.php ENDPATH**/ ?>