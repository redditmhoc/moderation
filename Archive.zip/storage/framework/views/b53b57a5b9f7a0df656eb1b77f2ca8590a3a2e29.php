<?php $__env->startSection('content'); ?>
<h1 class="ui huge header">MHoC Moderation
    <div class="sub header">
        This site is used to record MHoC Moderation actions.
    </div>
</h1>
<?php if(auth()->guard()->check()): ?>
    <p>Hi, <?php echo e(Auth::user()->username); ?>! You are a member of the <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <b><?php echo e($r); ?></b> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> group.</p>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access')): ?>
    <a href="<?php echo e(route('dash')); ?>" class="ui primary button">Access</a>
    <a href="<?php echo e(route('auth.logout')); ?>" class="ui red button">Sign-out</a>
    <?php else: ?>
    <div class="ui negative message">
        You are not registered as a member of Speakership. If this is a mistake, please contact the Quadrumvirate.
    </div>
    <a href="<?php echo e(route('auth.logout')); ?>" class="ui red button">Sign-out</a>
    <?php endif; ?>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <a href="<?php echo e(route('auth.login')); ?>" class="ui primary button">Login with Reddit</a>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-moderation/resources/views/welcome.blade.php ENDPATH**/ ?>