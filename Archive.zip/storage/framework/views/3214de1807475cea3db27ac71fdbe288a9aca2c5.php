<?php $__env->startSection('title', 'Dashboard - '); ?>
<?php $__env->startSection('content'); ?>
<h1 class="ui huge header">Dashboard</h1>
<div class="ui card">
    <div class="content">
      <div class="header"><?php echo e(Auth::user()->username); ?></div>
      <div class="meta">
        <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <i style="color:<?php echo e($r->colour); ?>" class="circle icon"></i> <?php echo e(ucfirst($r->name)); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="description">
        <a href="<?php echo e(route('auth.logout')); ?>" class="ui red tertiary button">Sign-out</a>
      </div>
    </div>
  </div>
  <br>
  <div class="ui grid">
      <div class="two-wide-column">
          <h3>Bans</h3>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create ban')): ?>
          <a href="<?php echo e(route('actions.createban')); ?>" class="ui primary button">Create Ban</a>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view actions')): ?>
          <a href="<?php echo e(route('actions.viewallbans')); ?>" class="ui button">View Bans</a>
          <?php endif; ?>
          <h3>Warnings</h3>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create warning')): ?>
          <a href="<?php echo e(route('actions.createwarning')); ?>" class="ui primary button">Create Warning</a>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view actions')): ?>
          <a href="<?php echo e(route('actions.viewallwarnings')); ?>" class="ui button">View Warnings</a>
          <?php endif; ?>
          <h3>Information</h3>
          <a href="<?php echo e(route('guidance')); ?>" class="ui button">Guidance and Templates</a>
          <a href="https://docs.google.com/spreadsheets/d/15W_5TU2r683_RRD7kM4NE_Eau7sywyJ2yB47yrPWU2c/edit#gid=313010852" class="ui button">Spreadsheet</a>
          <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
          <h3>Admin</h3>
          <a href="<?php echo e(route('admin.managepermissions')); ?>" class="ui button">Manage Permissions</a>
          <?php endif; ?>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-moderation/resources/views/dash.blade.php ENDPATH**/ ?>