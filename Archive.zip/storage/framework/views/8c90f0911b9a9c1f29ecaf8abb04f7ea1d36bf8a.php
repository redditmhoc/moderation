<?php $__env->startSection('content'); ?>

<div class="ui middle aligned center aligned grid">
    <div class="five wide column">
        <div class="ui fluid card">
            <div class="content">
                <h1 class="ui huge header">403 - Unauthorised
                </h1>
                <div class="ui negative message">
                    <?php echo e($exception->getMessage()); ?> If you believe this is a mistake, please contact an admin.
                </div>
                <a href="<?php echo e(route('auth.logout')); ?>" class="ui teritary button">Dashboard</a>
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('auth.login')); ?>" class="ui teritary primary button">Login with Reddit</a>
                    <p style="margin-top: 10px;">We do not receive your password, nor can we read posts or post on your behalf.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-speakership/resources/views/errors/403.blade.php ENDPATH**/ ?>