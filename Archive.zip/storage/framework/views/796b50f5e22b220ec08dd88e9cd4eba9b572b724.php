<?php $__env->startSection('title', 'Warning - '.$warning->reddit_username.' - '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="margin-top: 10px; margin-bottom: 10px;" class="ui grid container">
<div class="eight column wide">
<?php
function ordinal($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        return $number. 'th';
    else
        return $number. $ends[$number % 10];
}
?>
<a href="<?php echo e(route('actions.viewallwarnings')); ?>">◀ View Warnings</a><br>
<h1 class="ui header">Warning: <?php echo e($warning->reddit_username); ?> (<?php echo e(Carbon\Carbon::create($warning->timestamp)->toDateString()); ?>)</h1>
<br>
<div class="ui stackable three column grid">
    <div class="column">
        <div class="ui fluid card">
            <div class="content">
                <div class="header">User Information</div>
                <div class="ui list">
                    <div class="item">
                        <i class="reddit icon"></i>
                        <div class="content">
                        <a class="header" href="https://reddit.com/u/<?php echo e($warning->reddit_username); ?>">/u/<?php echo e($warning->reddit_username); ?></a>
                        </div>
                    </div>
                    <div class="item">
                        <i class="discord icon"></i>
                        <div class="content">
                            <?php echo e($warning->discord_user_id); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ui fluid card">
            <div class="content">
                <div class="header">Issued by</div>
                <div class="ui list">
                    <div class="item">
                        <i class="user icon"></i>
                        <div class="content">
                            <?php $__currentLoopData = $warning->moderator->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <i style="color:<?php echo e($r->colour); ?>" class="circle icon"></i>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($warning->moderator->username); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ui fluid card">
            <div class="content">
                <div class="header" style="margin-bottom: 10px;">Actions</div>
                <div class="ui fluid vertical buttons">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit warning')): ?>
                    <a href="#" class="ui button">Edit Warning</a>
                    <?php endif; ?>
                    <a href="#" id="exportB" class="ui button">Export</a>
                    <script>
                        $(document).on("click", "#exportB", function(){
                            $('#exportModal')
                                .modal('show')
                            ;
                        });
                    </script>
                    <a href="#" id="viewNotificationTemplateB" class="ui primary button">View Notification Template</a>
                    <script>
                        $(document).on("click", "#viewNotificationTemplateB", function(){
                            $('#notificationTemplateModal')
                                .modal('show')
                            ;
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
    <div class="column">
        <div class="ui fluid card">
            <div class="content">
                <div class="header">Warning Details</div>
                <div class="ui list">
                    <div class="item">
                        <i class="calendar icon"></i>
                        <div class="content">
                            <div class="header">Timestamp</div>
                            <?php echo e(Carbon\Carbon::create($warning->timestamp)->toDayDateTimeString()); ?> GMT
                        </div>
                    </div>
                    <div class="item">
                        <i class="calendar icon"></i>
                        <div class="content">
                            <div class="header">Muted time</div>
                            <?php echo e($warning->muted_minutes); ?> minutes
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="column">
        <div class="ui fluid card">
            <div class="content">
                <div class="header">Reasoning and Evidence</div>
                <div class="ui list">
                    <div class="item">
                        <div class="content">
                            <div class="header">Reason</div>
                            <?php echo e($warning->reason); ?>

                        </div>
                    </div>
                    <div class="item">
                        <div class="content">
                            <div class="header">Evidence</div>
                            <a href="<?php echo e($warning->evidence); ?>"><?php echo e($warning->evidence); ?></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="content">
                            <div class="header">Comments</div>
                            <?php if($warning->comments): ?>
                            <p><?php echo e($warning->comments); ?></p>
                            <?php else: ?>
                            None provided.
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="ui modal" id="notificationTemplateModal">
    <div class="header">Notification template</div>
    <div class="content">
        <p>
            This is an informal warning regarding your behaviour in the MHOC Main Server. This has been issued because <span class="ui red text"><?php echo e($warning->reason); ?>.</span> <?php if($warning->muted_minutes > 0): ?> Subsequently, you have been muted in the Server for <span class="ui red text"><?php echo e($warning->muted_minutes); ?></span> minutes to allow the situation to calm down / you to consider the potential ramifications should you continue with this behaviour. <?php endif; ?>
        </p>
        <p>
            This is a precautionary measure and will have no bearing on you moving forward. However, we ask that you take this warning seriously and adjust your behaviour upon your return to prevent you from breaking any rules and subsequently receiving a formal strike.
        </p>
    </div>
</div>
<div class="ui modal" id="exportModal">
    <div class="header">Export ban</div>
    <div class="content">
        <p>You can export the ban information to CSV, XML, or JSON. Not sure why you'd want to though...</p>
        <br>
        <div class="ui styled fluid accordion">
            <div class="title">
                <i class="dropdown icon"></i>
                Export to CSV
            </div>
            <div class="content">
                not implemented yet
            </div>
            <div class="title">
                <i class="dropdown icon"></i>
                Export to JSON
            </div>
            <div class="content">
                <textarea name="" readonly style="width:100%; height: 200px;" id="" cols="30" rows="10"><?php echo e($warning->toJson()); ?></textarea>
            </div>
            <div class="title">
                <i class="dropdown icon"></i>
                Export to XML
            </div>
            <div class="content">
                Not done yet either smh
            </div>
        </div>
        <script>
            $('.ui.accordion')
        .accordion()
        ;
        </script>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-speakership/resources/views/actions/viewWarning.blade.php ENDPATH**/ ?>