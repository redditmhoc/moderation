<?php $__env->startSection('content'); ?>
<h1 class="ui huge header">Create Ban/Warning</h1>
<div class="ui form">
    <div class="required field">
        <label for="">Reddit username</label>
        <input type="text" placeholder="Without the /u/">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-moderation/resources/views/actions/create.blade.php ENDPATH**/ ?>