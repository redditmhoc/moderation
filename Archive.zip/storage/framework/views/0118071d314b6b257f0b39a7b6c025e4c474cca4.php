<div class="ui container" style="margin-top: 20px;">
    <div class="ui secondary pointing menu">
        <a href="<?php echo e(route('dash')); ?>" class="<?php echo e(Request::is('dash') ? 'active' : ''); ?> item">
            Dashboard
        </a>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access')): ?>
        <div class="ui dropdown item">
            Moderation
            <i class="dropdown icon"></i>
            <div class="menu">
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view actions')): ?>
                <div class="divider"></div>
                <div class="header">Actions</div>
                <a href="<?php echo e(route('actions.viewallbans')); ?>" class="<?php echo e(Request::is('actions/view/bans') || Request::is('actions/view/ban/*') || Request::is('actions/create/ban') ? 'active' : ''); ?> item">Bans</a>
                <a href="<?php echo e(route('actions.viewallwarnings')); ?>" class="<?php echo e(Request::is('actions/view/warnings') || Request::is('actions/view/warning/*') || Request::is('actions/create/warning') ? 'active' : ''); ?> item">Warnings</a>
                <a id="viewUserHistoryB" href="#" class="item">User History</a>
                <script>
                    $(document).on("click", "#viewUserHistoryB", function(){
                        $('#userHistoryModal')
                            .modal('show')
                        ;
                    });
                </script>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access')): ?>
                <div class="divider"></div>
                <div class="header">Help</div>
                <a href="<?php echo e(route('guidance')); ?>" class="<?php echo e(Request::is('guidance') ? 'active' : ''); ?> item">Guidance & Templates</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <div class="ui dropdown item">
            Admin
            <i class="dropdown icon"></i>
            <div class="menu">
                <a href="<?php echo e(route('admin.managepermissions')); ?>" class="item">Manage Permissions</a>
            </div>
        </div>
        <?php endif; ?>
        <div class="right menu">
            <a target="_blank" href="https://reddit.com/r/mhoc" class="ui item">Go to /r/mhoc</a>
            <div href="#" class="ui dropdown item">
                <i class="user icon"></i> <b><?php echo e(Auth::user()->username); ?></b>
                <div class="menu">
                    <div class="header">
                        <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <i style="color:<?php echo e($r->colour); ?>" class="circle icon"></i> <?php echo e(ucfirst($r->name)); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="item" href="javascript:alert('This isn\'t available yet')"><i class="user icon"></i> View Your Data</a>
                    <a href="<?php echo e(route('auth.logout')); ?>" class="item"><i class="key icon"></i> Sign Out</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(" .ui.dropdown").dropdown();
    </script>
</div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view actions')): ?>
<div class="ui modal" id="userHistoryModal">
    <div class="header">View user history</div>
    <div class="content">
        <p>Enter a reddit username to view moderation history.</p>
        <div class="ui form">
        <div class="required field">
            <label for="">Reddit username</label>
            <input onblur="checkUserHistoryModal(this.value)" required type="text" name="redditUsername" placeholder="Without the /u/">
            <div style="margin-top: 10px;" id="userHistoryContainerModal"></div>
        </div>
        </div>
        <script>
            function checkUserHistoryModal (user) {
            $("#userHistoryContainerModal").html(`
                <div class="ui message">
                    <div class="ui active inline loader"></div>&nbsp;&nbsp;Checking history for /u/${user}....
                </div>
            `)
            $.ajax({
            type: 'POST',
            url: '/utility/checkuserhistory',
            data: {reddit_username:user},
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': $("meta[name='csrf-token']").attr('content')
            },
            success: function(data) {
                if (data.bans.length < 1 && data.warnings.length < 1) {
                    $("#userHistoryContainerModal").html(`
                        <div class="ui message">
                        No history found for /u/${user}.
                        </div>
                    `)
                } else {
                    $("#userHistoryContainerModal").html(`
                        <div class="ui negative message">
                            <div class="header">History found</div>
                            <div class="ui bulleted list ${user}-history-list">
                            </div>
                        </div>
                    `)
                    data.bans.forEach(ban => {
                        let item = $('<div></div>').addClass('item').html(
                            `
                            <div class="content">
                                ${getGetOrdinal(ban.strike_level)} Strike - ${ban.start_timestamp} - <a href="/actions/view/ban/${ban.reddit_username}/${ban.id}">View</a>
                            </div>
                            `
                        )
                        $(`#userHistoryContainerModal .${user}-history-list`).append(item);
                    })
                    data.warnings.forEach(warning => {
                        let item = $('<div></div>').addClass('item').html(
                            `
                            <div class="content">
                                Warning - ${warning.timestamp} - <a href="/actions/view/warning/${warning.reddit_username}/${warning.id}">View</a>
                            </div>
                            `
                        )
                        $(`#userHistoryContainerModal .${user}-history-list`).append(item);
                    })
                }
            },
            error: function(data) {
                $("#userHistoryContainerModal").html(`
                <div class="ui error message">
                    Error: ${data.responseJSON.message}
                </div>
                `)
            }
            })
        }
        </script>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /Users/lieseldownes/Documents/Git/mhoc-speakership/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>