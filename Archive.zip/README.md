## MHoC Speakership

Speakership web app for MHoC including moderation and vote counting

### Contributors

* Liesel (ellielia)
* Viljo (vijlow)
