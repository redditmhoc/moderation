<?php

namespace App\Http\Controllers\Speakership;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ModmailController extends Controller
{
    //
}
