<?php

namespace App\Models\Moderation;

use Illuminate\Database\Eloquent\Model;

class BanExpiryReminder extends Model
{
    //
}
